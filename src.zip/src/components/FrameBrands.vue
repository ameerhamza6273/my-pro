<template>
    <div>
        <div class="frame9 ">
            <v-row class="frame9-inner" align="center" >
                <img class="brand-images" src="Burger_King_2020.png" alt="user">
                <img class="brand-images" src="Domino's_pizza_logo.png" alt="user">
                <img class="brand-images" src="Subway_2016_logo.png" alt="user">
                <img class="brand-images" src="McDonald's_Golden_Arches.png" alt="user">
            </v-row>
        </div>
    </div>
</template>

<script>
export default {
    name: "FrameBrands",
    data() {
        return {
            // 
        }
    }
}
</script>

<style>

.frame9 {
    position: absolute;
    width: 976.76px;
    height: 120px;
    left: calc(54% - 1076.76px/2 + 0.38px);
    margin-top: -60px;
    background: rgba(255, 255, 255, 0.7) !important;
    box-shadow: 0px 6px 14px rgba(0, 0, 0, 0.2);
    backdrop-filter: blur(5px);
    border-radius: 25px;
}
.frame9-inner{
    justify-content: center;
}
.brand-images{
   padding: 40px;
}
</style>