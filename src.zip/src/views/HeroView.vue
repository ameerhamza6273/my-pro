<template>
  <div>
    <!-- hero section is here -->
    <HeroSection />
    <!-- bottom section of hero is here -->
    <FrameBrands />
    <!-- apply frame is here -->
    <ApplyFrame/>
    <!-- green card is here -->
    <GreenCard/>
  </div>
</template>

<script>
import HeroSection from "../components/HeroSection.vue";
import FrameBrands from "../components/FrameBrands.vue";
import ApplyFrame from "@/components/ApplyFrame.vue";
import GreenCard from "@/components/GreenCard.vue";
export default {
  name: "Home",

  components: {
    HeroSection,
    FrameBrands,
    ApplyFrame,
    GreenCard,
  },

};
</script>
