<template>
    <div>
        <div class="apply-frame">
            <h1 class="apply-frame-heading">Applying is Easy</h1>
            <p class="apply-frame-text mt-4">Applying for a green card through our company is a simple and user-friendly
                process.
            </p>
        </div>
        <div class="apply-frame-inner">
            <v-row class="justify-center">
                <v-card max-width="380" flat class="apply-frame-inner-cards">
                    <img alt="user" src="Clip path group.png" class="apply-frame-inner-cards-img">
                    <v-card-title class="apply-frame-inner-cards-heading">
                        Create Account
                    </v-card-title>
                    <v-card-text class="apply-frame-inner-cards-text">
                        <p>We work with reputable employers and find them the right candidates to fill in their positions.
                            We have several sponsors available and you may visit the client portal to choose a job and
                            location that best fits your needs.</p>
                    </v-card-text>
                </v-card>
                <v-card max-width="380" flat class="apply-frame-inner-cards" color="#4172A0" id="card-2">
                    <img alt="user" src="moneysend.png" class="apply-frame-inner-cards-img mt-10">
                    <v-card-title class="apply-frame-inner-cards-heading white--text mt-8">
                        Pay the Fee
                    </v-card-title>
                    <v-card-text class="apply-frame-inner-cards-text white--text">
                        <p>We lead the market when it comes to EB-3 Unskilled application processing charges. Our pricing
                            model gives our
                            clients the opportunity to apply for the program without being a burden to their finances. An
                            amazing instalment
                            plan is also available to cater to the needs of EB-3 Unskilled aspirants.</p>
                    </v-card-text>
                </v-card>
                <v-card max-width="380" flat class="apply-frame-inner-cards">
                    <img alt="user" src="Medal Icon.png" class="apply-frame-inner-cards-img">
                    <v-card-title class="apply-frame-inner-cards-heading ">
                        Your Journey Starts
                    </v-card-title>
                    <v-card-text class="apply-frame-inner-cards-text">
                        <p>Now that you have selected a job and have paid the fees, your US green card journey has begun.
                            Our administrative staff and team of attorneys will take care of you from now until you get your
                            green card.</p>
                    </v-card-text>
                </v-card>
            </v-row>
        </div>
    </div>
</template>

<script>
export default {
    name: "ApplyFrame",
    data() {
        return {
            // 
        }
    }
}
</script>

<style>
.apply-frame {
    margin-top: 170px;
}

.apply-frame-heading {
    font-family: 'Oswald';
    font-style: normal;
    font-weight: 700;
    font-size: 40px;
    line-height: 50px;
    text-align: center;
    color: #222222;
}

.apply-frame-text {
    font-family: 'Poppins';
    font-style: normal;
    font-weight: 400;
    font-size: 20px;
    line-height: 30px;
    text-align: center;
    color: #111827;
}

.apply-frame-inner{
    margin-top: 180px;
}

.apply-frame-inner-cards{
    border-radius: 24px !important;
    padding-top: 30px;
}

.apply-frame-inner-cards-img {
    margin: 0 auto;
    display: block;
}

.apply-frame-inner-cards-heading {
    justify-content: center;
    font-family: 'Poppins';
    font-style: normal;
    font-weight: 400;
    font-size: 28px;
    line-height: 35px;
    color: #222222;
    margin-top: 15px;
}

.apply-frame-inner-cards-text {
    font-family: 'Poppins';
    font-style: normal;
    font-weight: 300;
    font-size: 16px;
    line-height: 24px;
    text-align: center;
    color: #111827;
}
#card-2{
    margin-top: -90px;
}
</style>