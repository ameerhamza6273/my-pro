<template>
    <div>
        <div class="green-card">
            <h1 class="green-card-heading">Steps to Green Card (EB-3 Unskilled)</h1>
            <p class="green-card-text mt-5 mb-10">Achieve your dream of obtaining a green card through the EB-3
                Unskilled category by following our simplified steps to success.</p>
        </div>
        <v-col cols="12">
            <div>
                <v-row>
                    <v-col cols="12" sm="6">
                        <v-card v-for="(item, index) in jobArray" :key="index" flat tile>
                            <div class="green-card-inner">
                                <v-card-title class="green-card-inner-title ">
                                    {{ item.title }}
                                </v-card-title>
                            
                            </div>
                        </v-card>
                    </v-col>
                    <v-col cols="12" sm="6">hi</v-col>
                </v-row>
            </div>
        </v-col>
    </div>
</template>

<script>
export default {
    name: "GreenCard",
    data() {
        return {
            jobArray: [
                {
                    title: "Choose a job",
                    text: "Looking for a new job opportunity in the United States? We are here to help you choose the right job that fits your qualifications and expertise.",
                    img: "src"
                },
                {
                    title: "Pay the fee",
                    text: "Looking for a new job opportunity in the United States? We are here to help you choose the right job that fits your qualifications and expertise.",
                    img: "src"
                },
                {
                    title: "File PERM",
                    text: "Looking for a new job opportunity in the United States? We are here to help you choose the right job that fits your qualifications and expertise.",
                    img: "src"
                },
                {
                    title: "File I-140",
                    text: "Looking for a new job opportunity in the United States? We are here to help you choose the right job that fits your qualifications and expertise.",
                    img: "src"
                },
                {
                    title: "Consular Processing",
                    text: "Looking for a new job opportunity in the United States? We are here to help you choose the right job that fits your qualifications and expertise.",
                    img: "src"
                },
            ]
        }
    }
}
</script>

<style>
.green-card {
    margin-top: 120px;
}

.green-card-heading {
    font-family: 'Oswald';
    font-style: normal;
    font-weight: 700;
    font-size: 40px;
    line-height: 50px;
    text-align: center;
    color: #222222;
}

.green-card-text {
    font-family: 'Poppins';
    font-style: normal;
    font-weight: 300;
    font-size: 17px;
    line-height: 25px;
    text-align: center;
    color: #111827;
}

.green-card-inner::before {
    /* border-left: 2px solid #B0B7C3 !important;
    padding: 10px 40px 10px 40px; */
}

.green-card-inner-title {
    font-family: 'Poppins';
    font-style: normal;
    font-weight: 500;
    font-size: 27px;
    line-height: 35px;
    color: #111827;
    padding: 0;

}
</style>