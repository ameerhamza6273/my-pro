<template>
    <div>
        <div class="hero-section">
            <p class="hero-section-text">Now could be the PERFECT time to start your</p>
            <h1 class="hero-section-heading">US Green Card</h1>
            <h6 class="hero-section-subheading">jOURNEY</h6>
            <div class="hero-section-small-text">We have a vast experience in EB-3 Unskilled hiring and immigration
                process.
                Our clients are our top priority and we have built a platform with the needs of our clients in focus so
                that
                they can find the latest job opportunities that lead to a US green card.</div>
            <v-btn class="hero-section-btn">Apply Now</v-btn>
        </div>
    </div>
</template>

<script>
export default {
    name: "HeroSecion",
    data() {
        return {
            // 
        }
    }
}
</script>

<style>
.hero-section {
    min-height: 905px;
    padding-top: 130px;
    padding-bottom: 130px;
    background-image: url("../assets/ImagePlaceholder.png") !important;
    background-position: left;
}

.hero-section .hero-section-text {
    font-family: 'Poppins';
    font-style: normal;
    font-weight: 260;
    font-size: 27px;
    line-height: 40px;
    text-align: center;
    letter-spacing: 0.25em;
    text-transform: uppercase;
    color: #FFFFFF;
    text-shadow: 5px 20px 50px rgba(0, 0, 0, 0.05);
    margin-bottom: 0 !important;
}

.hero-section .hero-section-heading {
    font-family: 'Oswald';
    font-style: normal;
    font-weight: 650;
    font-size: 190px;
    line-height: 250px;
    text-align: center;
    color: #FFFFFF;
    text-shadow: 5px 20px 50px rgba(0, 0, 0, 0.1);
}

.hero-section-subheading {
    font-family: 'Poppins';
    font-style: normal;
    font-weight: 300;
    font-size: 32px;
    line-height: 48px;
    text-align: center;
    letter-spacing: 0.25em;
    text-transform: uppercase;
    color: #FFFFFF;
    text-shadow: 5px 20px 50px rgba(0, 0, 0, 0.05);
}

.hero-section .hero-section-small-text {
    font-family: 'Poppins';
    font-style: normal;
    font-weight: 150;
    font-size: 16px;
    line-height: 30px;
    text-align: center;
    color: #FFFFFF;
    margin-top: 70px;
    display: block;
    margin-left: auto;
    margin-right: auto;
    width: 65%;
}

.hero-section-btn {
    justify-content: center;
    padding: 27px 72px;
    width: 230px;
    height: 78px !important;
    left: calc(50% - 230px/2 - 50.5px);
    background-color: #041E42 !important;
    border-radius: 8px;
    font-family: 'Poppins';
    font-style: normal;
    font-weight: 500;
    font-size: 16px;
    line-height: 24px;
    color: #FFFFFF !important;
    text-transform: capitalize;
    margin-top: 80px;
}

</style>